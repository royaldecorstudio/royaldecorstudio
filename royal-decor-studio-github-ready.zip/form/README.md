# Enquiry Form

The website's booking/enquiry form is on `../contact.html`. It opens WhatsApp for enquiries, so no server or database is required.

To keep the site working on GitHub Pages, keep `index.html`, `contact.html`, and the `assets/` folder in the repository root.
